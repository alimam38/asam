# Georgia K-12 Standards Corpus Summary
## English Language Arts (2025)

**Package UUID:** `391c3abe-c1ec-4a4a-a942-c9e152b35102`  
**API Endpoint:** `https://case.georgiastandards.org/ims/case/vext/CFPackages/391c3abe-c1ec-4a4a-a942-c9e152b35102`  
**Last Updated:** [DATE]

---

## Structure Overview

```
ELA Package
├── Elementary (K-5)
│   ├── Kindergarten (23.00100)
│   ├── Grade 1 (23.00200)
│   ├── Grade 2 (23.00300)
│   ├── Grade 3 (23.00400)
│   ├── Grade 4 (23.00500)
│   └── Grade 5 (23.00600)
├── Middle (6-8)
│   ├── Grade 6 (23.00700)
│   ├── Grade 7 (23.00800)
│   └── Grade 8 (23.00900)
└── High (9-12)
    ├── Grades 9-10 (23.01000)
    └── Grades 11-12 (23.01100)
```

---

## Domain Codes

| Code | Domain |
|------|--------|
| R | Reading |
| L | Language |
| W | Writing |
| SL | Speaking & Listening |

---

## Big Ideas (Language Domain)

| Code | Big Idea |
|------|----------|
| L.GC | Grammar Conventions |
| L.GU | Grammar Usage |
| L.V | Vocabulary |

---

## Skill Statistics

| Grade | Standards | Skills | With Teacher Notes |
|-------|-----------|--------|-------------------|
| K | [X] | [X] | [X] |
| 1 | [X] | [X] | [X] |
| 2 | [X] | [X] | [X] |
| 3 | [X] | [X] | [X] |
| 4 | [X] | [X] | [X] |
| 5 | [X] | [X] | [X] |
| 6 | [X] | [X] | [X] |
| 7 | [X] | [X] | [X] |
| 8 | [X] | [X] | [X] |
| 9-10 | [X] | [X] | [X] |
| 11-12 | [X] | [X] | [X] |

**Total Skills:** [X]  
**With Progression Tables:** [X]  
**With Supplemental Notes:** [X]

---

## Mastery Progression Example

**Skill:** Form regular plural nouns (-s/-es)

| Grade | Code | Mastery Level |
|-------|------|---------------|
| K | K.L.GC.1.5 | Introduce |
| 1 | 1.L.GC.1.5 | Master |

**Skill:** Use adjectives and adverbs

| Grade | Code | Mastery Level |
|-------|------|---------------|
| K | K.L.GC.1.8 | Introduce |
| 1 | 1.L.GC.1.8 | Continue |
| 2 | 2.L.GC.1.8 | Master |

---

## Sample Skill Record

```json
{
  "code": "K.L.GC.1.5",
  "statement": "Form regular plural nouns orally by adding /s/ or /es/",
  "category": "Grammar",
  "education_levels": ["KG"],
  "mastery": "Introduce",
  "standard": "K.L.GC.1",
  "big_idea": "Grammar Conventions",
  "domain": "Language",
  "has_teacher_notes": true
}
```

---

## Teacher Resource Example (from vext API)

**Standard:** K.L.GC.1 - Grammar Conventions

**Vocabulary:**
- Nouns, Verbs, Adjectives, Adverbs, Pronouns, Prepositions

**Instructional Strategies:**
- Use authentic examples from texts
- Create reference charts
- Mentor sentence protocols
- Provide examples and non-examples

**Evidence of Student Learning:**
```
Teacher: "Listen to this sentence: The cow jumped over the moon."
Teacher: "Who or what was that sentence about?"
Student: "The cow"
Teacher: "What was the cow doing?"
Student: "Jumping"
```

---

## Notes

- Use `vext` API for teacher resources and progression tables
- `v1p1` sufficient for basic hierarchy
- Mastery markers appear in `fullStatement` as "(Introduce)", "(Continue)", "(Master)"
- K-12 progression codes use format `K-12.L.GC.1.8` spanning all grades

---

*Template generated for Meridia Education Platform*
