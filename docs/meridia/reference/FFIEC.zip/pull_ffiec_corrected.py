# feeds/pull_ffiec.py
# ============================================================
# FFIEC Census Flat File Loader — Corrected for actual format
#
# The FFIEC flat file is ONE national file (~1,200 fields,
# all US tracts). It is NOT broken down by state at download.
# This script:
#   1. Reads the full national CSV
#   2. Filters to your target states (default: Georgia)
#   3. Maps the real FFIEC column names to your schema
#   4. Loads into census_tracts table
#
# Usage:
#   python feeds/pull_ffiec.py
#   python feeds/pull_ffiec.py --file /path/to/ffiec_2024.csv
#   python feeds/pull_ffiec.py --states GA FL AL  (multiple states)
#
# Download the file from:
#   https://www.ffiec.gov/data/census/flat-files
#   Get the most recent year (2024 or 2025)
# ============================================================

import asyncio
import argparse
import sys
import os
from pathlib import Path
import pandas as pd
from sqlalchemy import text
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from loguru import logger

sys.path.insert(0, str(Path(__file__).parent.parent))
from config import settings

engine = create_async_engine(settings.DATABASE_URL, echo=False)
AsyncSessionLocal = async_sessionmaker(engine, class_=AsyncSession, expire_on_commit=False)

# ── KNOWN FFIEC COLUMN MAPPINGS ───────────────────────────
# The FFIEC flat file column names vary slightly by year.
# This maps known variations to standardized names.
# If your file has different column names, check the
# documentation PDF that comes with the download.

COLUMN_CANDIDATES = {
    'state_code': [
        'STCODE', 'STATE_CODE', 'STATE', 'ST_CODE',
        'State Code', 'state_code', 'STATEFP'
    ],
    'county_code': [
        'CNTYCODE', 'COUNTY_CODE', 'COUNTY', 'COUNTYFP',
        'County Code', 'county_code'
    ],
    'tract_code': [
        'TRACTCODE', 'TRACT_CODE', 'TRACT', 'TRACTCE',
        'Census Tract', 'tract_code', 'CENSUSTRACT'
    ],
    'msa_code': [
        'MSACODE', 'MSA_CODE', 'MSA', 'CBSACODE',
        'MSA/MD Code', 'msa_code'
    ],
    'msa_name': [
        'MSANAME', 'MSA_NAME', 'MSA Name', 'msa_name',
        'CBSANAME', 'MSA/MD Name'
    ],
    'income_level': [
        'INCOMELEVEL', 'INCOME_LEVEL', 'Income Level',
        'income_level', 'TRACTINCOMELEVEL', 'TRACT_INCOME_LEVEL'
    ],
    'tract_mfi_pct': [
        'TRACTMFIPCT', 'TRACT_MFI_PCT', 'Tract MFI %',
        'tract_mfi_pct', 'PCTOFMFI', 'PCT_OF_MFI',
        'Tract Median Family Income as % of MSA/MD Median',
        'TRACTMFI_PCT'
    ],
    'is_distressed': [
        'DISTRESSED', 'IS_DISTRESSED', 'Distressed',
        'distressed', 'DISTRESSEDFLAG', 'DISTRESSED_FLAG',
        'CRA Distressed', 'CRADISTRESSED'
    ],
    'is_underserved': [
        'UNDERSERVED', 'IS_UNDERSERVED', 'Underserved',
        'underserved', 'UNDERSERVEDFLAG', 'UNDERSERVED_FLAG',
        'CRA Underserved', 'CRAUNDERSERVED'
    ],
    'population': [
        'POPULATION', 'POP', 'Total Population',
        'population', 'TOTPOP', 'TOT_POP'
    ],
    'minority_pct': [
        'MINORITYPCT', 'MINORITY_PCT', 'Minority %',
        'minority_pct', 'PCTMINORITY', 'PCT_MINORITY'
    ],
    'county_name': [
        'COUNTYNAME', 'COUNTY_NAME', 'County Name',
        'county_name', 'CTYNAME'
    ],
}

# State name to FIPS code mapping
STATE_FIPS = {
    'AL':'01','AK':'02','AZ':'04','AR':'05','CA':'06',
    'CO':'08','CT':'09','DE':'10','FL':'12','GA':'13',
    'HI':'15','ID':'16','IL':'17','IN':'18','IA':'19',
    'KS':'20','KY':'21','LA':'22','ME':'23','MD':'24',
    'MA':'25','MI':'26','MN':'27','MS':'28','MO':'29',
    'MT':'30','NE':'31','NV':'32','NH':'33','NJ':'34',
    'NM':'35','NY':'36','NC':'37','ND':'38','OH':'39',
    'OK':'40','OR':'41','PA':'42','RI':'44','SC':'45',
    'SD':'46','TN':'47','TX':'48','UT':'49','VT':'50',
    'VA':'51','WA':'53','WV':'54','WI':'55','WY':'56',
    'DC':'11','PR':'72',
}

def find_column(df_cols, candidates):
    """Find the first matching column name from candidates."""
    cols_upper = {c.upper().strip(): c for c in df_cols}
    for candidate in candidates:
        if candidate.upper().strip() in cols_upper:
            return cols_upper[candidate.upper().strip()]
    return None

def map_columns(df):
    """Map FFIEC columns to standardized names. Returns mapping dict."""
    mapping = {}
    unmapped = []
    for standard_name, candidates in COLUMN_CANDIDATES.items():
        col = find_column(df.columns, candidates)
        if col:
            mapping[standard_name] = col
        else:
            unmapped.append(standard_name)

    if unmapped:
        logger.warning(f"Could not map columns: {unmapped}")
        logger.info("Available columns (first 50):")
        for c in sorted(df.columns)[:50]:
            logger.info(f"  {c}")

    return mapping

def parse_bool_flag(val):
    """Parse various FFIEC boolean flag formats."""
    if pd.isna(val):
        return False
    s = str(val).strip().upper()
    return s in ['1', 'Y', 'YES', 'TRUE', 'X', 'T']

def build_geoid(state, county, tract):
    """Build 11-digit GEOID from FFIEC components."""
    # FFIEC stores state as 2-digit, county as 3-digit
    # tract as 6-digit (with decimal in some formats)
    state_str = str(state).strip().zfill(2)
    county_str = str(county).strip().zfill(3)
    # Tract may come as "0102.00" or "010200" or "102"
    tract_str = str(tract).strip().replace('.', '')
    tract_str = tract_str.zfill(6)
    return f"{state_str}{county_str}{tract_str}"

async def load_ffiec(file_path: str, target_states: list):
    """Load FFIEC flat file into census_tracts table."""

    path = Path(file_path)
    if not path.exists():
        logger.error(f"""
╔══════════════════════════════════════════════════════════════╗
║  FFIEC FILE NOT FOUND                                        ║
║                                                              ║
║  File not found at: {str(path):<40}║
║                                                              ║
║  Download the file:                                          ║
║  1. Go to: https://www.ffiec.gov/data/census/flat-files      ║
║  2. Download: 2024 Census Flat File (or most recent)         ║
║  3. Extract the ZIP if needed                                ║
║  4. Run: python feeds/pull_ffiec.py --file /path/to/file.csv ║
╚══════════════════════════════════════════════════════════════╝
        """)
        return

    logger.info(f"Loading FFIEC flat file: {path.name}")
    logger.info(f"Target states: {target_states}")
    logger.info("Reading file — this may take 30-60 seconds for the full national file...")

    # Convert state abbreviations to FIPS codes for filtering
    target_fips = []
    for s in target_states:
        s_upper = s.upper().strip()
        if s_upper in STATE_FIPS:
            target_fips.append(STATE_FIPS[s_upper])
        elif len(s_upper) == 2 and s_upper.isdigit():
            target_fips.append(s_upper)
        else:
            logger.warning(f"Unknown state: {s}")

    logger.info(f"Target FIPS codes: {target_fips}")

    # Read the file — try different encodings
    df = None
    for encoding in ['utf-8', 'latin-1', 'cp1252']:
        try:
            # Read with low_memory=False to handle mixed types
            df = pd.read_csv(file_path, dtype=str, low_memory=False, encoding=encoding)
            logger.info(f"File read successfully ({encoding}) — {len(df):,} rows, {len(df.columns)} columns")
            break
        except UnicodeDecodeError:
            continue
        except Exception as e:
            logger.error(f"Failed to read file: {e}")
            return

    if df is None:
        logger.error("Could not read file with any encoding")
        return

    # Map columns
    col_map = map_columns(df)

    if 'state_code' not in col_map:
        logger.error("Cannot find state code column. Check column mapping above and update COLUMN_CANDIDATES.")
        return

    # Filter to target states
    state_col = col_map['state_code']
    df['_state_fips'] = df[state_col].astype(str).str.strip().str.zfill(2)
    df_filtered = df[df['_state_fips'].isin(target_fips)].copy()
    logger.info(f"Filtered to {len(df_filtered):,} tracts in target states")

    if len(df_filtered) == 0:
        logger.error(f"No rows found for states {target_fips}.")
        logger.info(f"Sample values in state column '{state_col}': {df[state_col].unique()[:10]}")
        return

    # Build records
    inserted = 0
    updated = 0
    errors = 0

    async with AsyncSessionLocal() as db:
        for _, row in df_filtered.iterrows():
            try:
                state = str(row.get(col_map.get('state_code',''), '')).strip().zfill(2)
                county = str(row.get(col_map.get('county_code',''), '')).strip().zfill(3)
                tract = str(row.get(col_map.get('tract_code',''), '')).strip()
                geoid = build_geoid(state, county, tract)

                # Parse income percentage
                income_pct_raw = row.get(col_map.get('tract_mfi_pct', ''), None)
                income_pct = None
                if income_pct_raw and str(income_pct_raw).strip() not in ['', 'NA', 'N/A', 'nan']:
                    try:
                        income_pct = float(str(income_pct_raw).replace('%','').strip())
                    except:
                        pass

                # Income level determines LMI status
                income_level = str(row.get(col_map.get('income_level',''), '')).strip().upper()
                is_lmi = income_level in ['LOW', 'MODERATE', 'L', 'M', '1', '2'] or (
                    income_pct is not None and income_pct < 80
                )

                # Distressed / underserved flags
                is_distressed = parse_bool_flag(row.get(col_map.get('is_distressed',''), ''))
                is_underserved = parse_bool_flag(row.get(col_map.get('is_underserved',''), ''))

                # Population
                pop_raw = row.get(col_map.get('population',''), None)
                population = None
                if pop_raw and str(pop_raw).strip() not in ['', 'nan']:
                    try: population = int(float(str(pop_raw)))
                    except: pass

                # Minority percentage
                min_pct_raw = row.get(col_map.get('minority_pct',''), None)
                minority_pct = None
                if min_pct_raw and str(min_pct_raw).strip() not in ['', 'nan']:
                    try: minority_pct = float(str(min_pct_raw).replace('%','').strip())
                    except: pass

                # MSA and county names
                msa_name = str(row.get(col_map.get('msa_name',''), '')).strip() or None
                county_name = str(row.get(col_map.get('county_name',''), '')).strip() or None

                # Opportunity score — composite of LMI, distressed, underserved
                opp_score = 0.0
                if is_lmi: opp_score += 40.0
                if is_distressed: opp_score += 30.0
                if is_underserved: opp_score += 20.0
                if income_pct and income_pct < 60: opp_score += 10.0

                result = await db.execute(text("""
                    INSERT INTO census_tracts
                        (geoid, state_code, county_code, tract_name, msa_name,
                         is_distressed, is_underserved, is_lmi, ffiec_income_pct,
                         population, pct_minority, opportunity_score, data_year, updated_at)
                    VALUES
                        (:geoid, :state, :county, :tract_name, :msa_name,
                         :dist, :underserv, :lmi, :income_pct,
                         :pop, :minority_pct, :opp_score, 2024, NOW())
                    ON CONFLICT (geoid) DO UPDATE SET
                        msa_name = EXCLUDED.msa_name,
                        is_distressed = EXCLUDED.is_distressed,
                        is_underserved = EXCLUDED.is_underserved,
                        is_lmi = EXCLUDED.is_lmi,
                        ffiec_income_pct = EXCLUDED.ffiec_income_pct,
                        population = EXCLUDED.population,
                        pct_minority = EXCLUDED.pct_minority,
                        opportunity_score = EXCLUDED.opportunity_score,
                        updated_at = NOW()
                    RETURNING (xmax = 0) AS was_insert
                """), {
                    "geoid": geoid, "state": state, "county": county,
                    "tract_name": county_name, "msa_name": msa_name,
                    "dist": is_distressed, "underserv": is_underserved,
                    "lmi": is_lmi, "income_pct": income_pct,
                    "pop": population, "minority_pct": minority_pct,
                    "opp_score": opp_score
                })

                row_result = result.fetchone()
                if row_result and row_result[0]:
                    inserted += 1
                else:
                    updated += 1

                # Commit in batches
                if (inserted + updated) % 500 == 0:
                    await db.commit()
                    logger.info(f"  Progress: {inserted} inserted, {updated} updated...")

            except Exception as e:
                errors += 1
                if errors <= 5:
                    logger.debug(f"Row error: {e}")

        await db.commit()

        # Log result
        await db.execute(text("""
            INSERT INTO data_pull_log (source, pull_type, status, records_inserted, records_updated, completed_at)
            VALUES ('ffiec', 'full', 'success', :ins, :upd, NOW())
        """), {"ins": inserted, "upd": updated})
        await db.commit()

    logger.info(f"""
FFIEC load complete:
  Inserted: {inserted:,}
  Updated:  {updated:,}
  Errors:   {errors:,}
  States:   {target_states}
    """)

    if inserted + updated == 0:
        logger.warning("No records loaded. Check column mapping above.")


# ══════════════════════════════════════════════════════════
# PLAID INTEGRATION — Feed Layer Adapter
# ══════════════════════════════════════════════════════════

async def pull_plaid_accounts(user_access_token: str, user_id: str):
    """
    Pull account and transaction data from Plaid for a single user.
    Called after user completes Plaid Link flow and you have their access_token.

    Products used: Transactions, Assets, Liabilities, Recurring Transactions

    This feeds the FPS calculation engine with real consumer data.
    """
    import httpx
    from config import settings

    headers = {
        "Content-Type": "application/json",
        "PLAID-CLIENT-ID": settings.PLAID_CLIENT_ID,
        "PLAID-SECRET": settings.PLAID_SECRET,
    }

    base_url = f"https://{settings.PLAID_ENV}.plaid.com"
    results = {}

    async with httpx.AsyncClient(timeout=30.0) as client:

        # ── ACCOUNTS ──────────────────────────────────────
        resp = await client.post(f"{base_url}/accounts/get",
            headers=headers,
            json={"access_token": user_access_token}
        )
        if resp.status_code == 200:
            results['accounts'] = resp.json().get('accounts', [])
            logger.info(f"Plaid accounts: {len(results['accounts'])} accounts")

        # ── TRANSACTIONS (24 months) ───────────────────────
        from datetime import datetime, timedelta
        end_date = datetime.now().strftime('%Y-%m-%d')
        start_date = (datetime.now() - timedelta(days=730)).strftime('%Y-%m-%d')

        resp = await client.post(f"{base_url}/transactions/get",
            headers=headers,
            json={
                "access_token": user_access_token,
                "start_date": start_date,
                "end_date": end_date,
                "options": {"count": 500, "offset": 0}
            }
        )
        if resp.status_code == 200:
            data = resp.json()
            results['transactions'] = data.get('transactions', [])
            results['total_transactions'] = data.get('total_transactions', 0)
            logger.info(f"Plaid transactions: {len(results['transactions'])} of {results['total_transactions']}")

        # ── LIABILITIES ───────────────────────────────────
        resp = await client.post(f"{base_url}/liabilities/get",
            headers=headers,
            json={"access_token": user_access_token}
        )
        if resp.status_code == 200:
            results['liabilities'] = resp.json().get('liabilities', {})
            logger.info(f"Plaid liabilities: loaded")
        elif resp.status_code == 400:
            # No liabilities on this account — normal
            results['liabilities'] = {}

        # ── RECURRING TRANSACTIONS ─────────────────────────
        resp = await client.post(f"{base_url}/transactions/recurring/get",
            headers=headers,
            json={"access_token": user_access_token}
        )
        if resp.status_code == 200:
            data = resp.json()
            results['recurring_inflows'] = data.get('inflow_streams', [])
            results['recurring_outflows'] = data.get('outflow_streams', [])
            logger.info(f"Plaid recurring: {len(results['recurring_inflows'])} inflows, {len(results['recurring_outflows'])} outflows")

    return results


# ══════════════════════════════════════════════════════════
# MX INTEGRATION — Feed Layer Adapter
# ══════════════════════════════════════════════════════════

async def pull_mx_accounts(mx_user_guid: str):
    """
    Pull account and transaction data from MX for a single user.
    MX is the alternative to Plaid — same data, different rail.

    Use MX for institutions where Plaid has limited coverage,
    or as a fallback when Plaid connection fails.
    """
    import httpx
    import base64
    from config import settings

    # MX uses Basic Auth
    credentials = base64.b64encode(
        f"{settings.MX_CLIENT_ID}:{settings.MX_API_KEY}".encode()
    ).decode()

    headers = {
        "Authorization": f"Basic {credentials}",
        "Accept": "application/vnd.mx.api.v1+json",
        "Content-Type": "application/json",
    }

    base_url = "https://api.mx.com" if settings.MX_ENV == "production" else "https://int-api.mx.com"
    results = {}

    async with httpx.AsyncClient(timeout=30.0) as client:

        # ── ACCOUNTS ──────────────────────────────────────
        resp = await client.get(
            f"{base_url}/users/{mx_user_guid}/accounts",
            headers=headers
        )
        if resp.status_code == 200:
            results['accounts'] = resp.json().get('accounts', [])
            logger.info(f"MX accounts: {len(results['accounts'])} accounts")

        # ── TRANSACTIONS ───────────────────────────────────
        from datetime import datetime, timedelta
        start = (datetime.now() - timedelta(days=730)).strftime('%Y-%m-%d')

        resp = await client.get(
            f"{base_url}/users/{mx_user_guid}/transactions",
            headers=headers,
            params={"from_date": start, "records_per_page": 1000}
        )
        if resp.status_code == 200:
            results['transactions'] = resp.json().get('transactions', [])
            logger.info(f"MX transactions: {len(results['transactions'])}")

    return results


# ══════════════════════════════════════════════════════════
# CONFIG ADDITIONS — Add these to your config.py
# ══════════════════════════════════════════════════════════

PLAID_CONFIG_ADDITIONS = """
# ── PLAID ─────────────────────────────────────────────────
# Add these to config.py Config dataclass

PLAID_CLIENT_ID: str = os.getenv("PLAID_CLIENT_ID", "YOUR_PLAID_CLIENT_ID")
PLAID_SECRET: str = os.getenv("PLAID_SECRET", "YOUR_PLAID_SANDBOX_SECRET")
PLAID_ENV: str = os.getenv("PLAID_ENV", "sandbox")  # sandbox | development | production

# ── MX ────────────────────────────────────────────────────
MX_CLIENT_ID: str = os.getenv("MX_CLIENT_ID", "YOUR_MX_CLIENT_ID")
MX_API_KEY: str = os.getenv("MX_API_KEY", "YOUR_MX_API_KEY")
MX_ENV: str = os.getenv("MX_ENV", "sandbox")  # sandbox | production
"""

ENV_ADDITIONS = """
# Add these to your .env file:

PLAID_CLIENT_ID=your_client_id_here
PLAID_SECRET=your_sandbox_secret_here
PLAID_ENV=sandbox

MX_CLIENT_ID=your_mx_client_id_here
MX_API_KEY=your_mx_api_key_here
MX_ENV=sandbox
"""


# ══════════════════════════════════════════════════════════
# RUNNER
# ══════════════════════════════════════════════════════════

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='FFIEC Census Flat File Loader')
    parser.add_argument('--file', type=str,
                        default='./data/ffiec/ffiec_census_flat.csv',
                        help='Path to the downloaded FFIEC flat file CSV')
    parser.add_argument('--states', nargs='+', default=['GA'],
                        help='State abbreviations to load (default: GA)')
    args = parser.parse_args()

    print(f"\nFFIEC Census Flat File Loader")
    print(f"File: {args.file}")
    print(f"States: {args.states}")
    print(f"\nIf file is a ZIP, extract it first.")
    print(f"Expected: large CSV with ~1,200 columns, all US tracts\n")

    asyncio.run(load_ffiec(args.file, args.states))
