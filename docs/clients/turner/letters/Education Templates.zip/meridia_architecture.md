# Meridia System Architecture
## Sovereign Financial & Education Infrastructure

**Version:** 0.1  
**Last Updated:** February 2026  
**Author:** Ali (Architect) + Claude (Technical Partner)

---

## Vision

Meridia is a sovereign infrastructure platform that combines:
- **Financial Positioning System (FPS)** — Aegis dashboard for wealth stewardship
- **Education Platform** — K-12 adaptive learning aligned to Georgia standards
- **AI Steward (Aletheia)** — Governed intelligence layer

The system operates on sovereign hardware (Meridia Core NAS) with cloud as transit, not dependency.

---

## Core Principles

| Principle | Description |
|-----------|-------------|
| **Sovereign First** | Data lives on owned hardware, cloud is backup |
| **Governance Not Guardrails** | Intent-based access, not hard blocks |
| **Bilateral Integration** | Established institutions can see in, we can see out |
| **Dignity Path** | Renaissance tier serves the excluded with respect |

---

## System Components

### Hardware Layer

```
MERIDIA CORE (Synology DS925+)
├── 2x 6TB Toshiba N300 (RAID 1)
├── 2x 1TB NVMe Cache
├── 34GB RAM
├── Encrypted Btrfs Volume
└── Container Manager (Docker)

DESKTOP (ROG 700TF)
├── Development workstation
├── 2TB NVMe added
└── VS Code, Python, testing

LEGION PRO 7i (Future)
├── RTX 5080 16GB
├── 64GB RAM
├── Local LLM inference
└── Mobile sovereign node
```

### Software Stack

```
CONTAINERS (on NAS)
├── PostgreSQL — Standards, users, progress
├── FastAPI — REST API layer
├── Redis — Sessions, cache, queues
├── Gitea — Sovereign code repository
└── Integra — Orchestration layer (future)

APPLICATIONS
├── Aegis (FPS) — Index8.html prototype
├── Education App — K-12 learning
├── Parent Portal — Progress viewing
└── Renaissance — Credit rebuilding
```

---

## Data Architecture

### Georgia Standards Corpus

**Source:** Georgia DOE CASE API (IMS Global spec)

| Subject | UUID | Status |
|---------|------|--------|
| ELA | `391c3abe-c1ec-4a4a-a942-c9e152b35102` | ✅ |
| Math | `e9dd7229-3558-4df2-85c6-57b8938f6180` | ✅ |
| Science | `27a08dc6-416e-11e7-ba71-02bd89fdd987` | Ready |
| Social Studies | `a446e74c-463e-11e7-94f5-b49cee8b2d8c` | Ready |
| Computer Science | `00fcf0e2-b9c3-11e7-a4ad-47f36833e889` | Ready |
| CTAE | `7b0f1da9-9e17-4e65-af93-fb74851175d2` | Ready |

**Hierarchy:**
```
Package → Grade Band → Course → Domain → Big Idea → Standard → Skill
```

**Key Features (vext API):**
- K-12 skill progression tables
- Teacher supplemental notes
- Instructional strategies
- Assessment evidence templates

### Database Schema

Core tables: `subject_packages`, `grade_bands`, `courses`, `domains`, `big_ideas`, `standards`, `skills`

Tracking: `skill_mastery`, `skill_progressions`, `student_skill_progress`

Views: `v_skills_full`, `v_skill_progressions`, `v_student_progress_summary`

---

## Client Tiers

| Tier | Description | Access Level |
|------|-------------|--------------|
| **Renaissance** | Credit rebuilders, excluded populations | Dignity path, basic tools |
| **Core** | Established families, growing assets | Full FPS, education platform |
| **Legacy** | Generational wealth, stewardship focus | Multi-entity, governance |
| **Edge** | Specialized verticals (cannabis, etc.) | Partner banking integration |

---

## AI Layer

### Aletheia (Steward Guide)

- **Interface:** Chat panel in all applications
- **Modes:** 
  - Cloud (Claude API) — Complex reasoning
  - Local (Legion LLM) — Fast inference, offline
- **Governance:** Multi-party approval for sensitive insights

### Governess Signal (Future)

- Quarterly AI-generated reports
- Governs product availability by tier
- Analyzes market trends, insurance ratings
- Provides route adjustments as conditions change

---

## Integration Points

| System | Purpose | Status |
|--------|---------|--------|
| Georgia CASE API | Standards ingestion | ✅ Working |
| Plaid/Finicity | Account aggregation | Phase 4 |
| Claude API | AI fallback | Ready |
| Institutional Partners | Sandbox access | Phase 4 |

---

## Development Workflow

```
1. Design session with Claude (here)
2. Code on desktop (VS Code)
3. Commit to Gitea (NAS)
4. Deploy containers (NAS)
5. Test via FastAPI docs
6. Iterate
```

---

## Deployment Phases

| Phase | Focus | Timeline |
|-------|-------|----------|
| **0** | NAS + PostgreSQL + Schema | This week |
| **1** | Standards corpus + basic UI | 2-3 weeks |
| **2** | FastAPI + Aegis backend | 4-6 weeks |
| **3** | Local LLM + Aletheia | 6-8 weeks |
| **4** | Plaid + institutional pilot | 8-12 weeks |
| **5** | Distribution (PTO networks) | 12+ weeks |

---

## File Locations

| Content | Location |
|---------|----------|
| Canonical data | Meridia Core NAS `/corpus/` |
| Code repos | Gitea on NAS |
| Claude context | Project Knowledge (summaries) |
| Overflow/backup | Google Drive |
| Working docs | This Project |

---

## Key Documents

- `ela_summary.md` — ELA standards overview
- `skill_index.json` — Searchable skill reference
- `schema.sql` — PostgreSQL database schema
- `extractor.py` — Standards extraction tool
- `models.py` — Pydantic data models

---

*This document is the source of truth for system architecture.*
*Update as decisions are made.*
